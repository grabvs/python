"""
Zadanie 4
"""

def loadFile(nazwa="liczby.txt"):
    try:
        with open(nazwa, "r") as file:
            liczby = file.read().split()
            
        return liczby
    except FileNotFoundError as err:
        print(f"nie znaleziono pliku: {err}")
    except Exception as err:
        print(f"nieoczekiwany blad: {err}")
        
def zadanie4_1(liczby):
    ile=0
    for liczba in liczby:
        ile_1,ile_0 = 0,0
            
        for znak in liczba:
            if znak == "0":
                ile_0 += 1
            elif znak =="1":
                ile_1 += 1
        if ile_0 > ile_1:
            ile+=1
    print(ile)

def zadanie4_2(liczby):
    przezDwa = 0
    przezOsiem = 0
    for wiersz in liczby:
        ostatnia = wiersz[-1]
        if (ostatnia == "0"):
            przezDwa += 1
        trzyOstatnie = wiersz[-1 : -4 : -1]
        if (trzyOstatnie == '000'):
            przezOsiem += 1
    print(f"podzielne przez 2: {przezDwa}, podzielne przez 8: {przezOsiem}")
    
def main():
    loadedNumbers = loadFile()
    zadanie4_1(loadedNumbers)
    zadanie4_2(loadedNumbers)


if __name__ == "__main__":
    main()